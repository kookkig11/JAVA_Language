package MainProgram.Dictionary;

public interface MyFormatter {
    String format(Object obj);
}
